#include <iostream>

#include "Parent.h"
#include "Child.h"

using namespace std;


void UseParent (Parent &_p)
{
  cout << "UseParent(): " << _p.toString() << endl;
  _p.override();
}


int main (int argc, char ** argv)
{
  Parent A(1.0, 2.0);
  Child B(1.0, 2.0);

  cout << "Parent: " << A.toString() << endl;
  cout << " Child: " << B.toString() << endl;
  cout << endl;

  UseParent(A);
  UseParent(B);

  A.override();
  B.override();

  return 0;
}
