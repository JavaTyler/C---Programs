#include <iostream>
#include "Implement.h"
#include "InterfaceSpec.h"

using namespace std;

int main (int argc, char **argv)
{
    Implement imp;

    cout << "Direct calls though Implement class" << endl;
    imp.Function01();
    imp.Function01(10);
    imp.Function02();
    imp.Function03();
    
    // -- A variable of type abstact (pure) class must be a pointer type,
    //    otherwise the compiler will try to create a call to the
    //    default constructor.
    InterfaceSpec *iface;
    // -- Principle of Substitution says that imp "is-a" Interface
    //    (through inheritance) and therefore can be assigned
    //    But, since iface is a pointer you must assign a reference
    //    to imp (the address of imp), not the imp object.
    iface = &imp;
    
    cout << "Substitution calls though InterfaceSpec class" << endl;
    iface->Function01();
    iface->Function01(10);
    iface->Function02();
    iface->Function03();

    return 0;
}
