#include <iostream>
#include "Implement.h"

using namespace std;

Implement::Implement()
    : x(0)
{
    cout << "Implement constructor" << endl;
}

Implement::~Implement()
{
    cout << "Implement destructor" << endl;
}

void Implement::Function01()  const
{
    cout << "Implement Function01()" << endl;
}

void Implement::Function01(const int n)  const
{
    cout << "Implement Function01(int n)" << endl;
}

void Implement::Function02()  const
{
    cout << "Implement Function02()" << endl;
}

void Implement::Function03()  const
{
    cout << "Implement Function03()" << endl;
}
