#pragma once

#include <iostream>

using namespace std;

class InterfaceSpec
{
 public:
    // -- pure (abstract) functions must be declared virtual
    //    to notify the compiler that objects will be bound
    //    at run-time (as opposed to compile-time.
    //    This will create an entry in the V-Table to ensure
    //    proper function calls at run-time
    virtual void Function01() const = 0;
    virtual void Function01(const int n) const = 0;
    virtual void Function02() const = 0;

    // -- since this is a concrete function, it need not be declared
    //    virtual. But, doing so will create a V-Table entry (see above)
    //    to alter the run-time behavior if delcared in the implementation
    //    class
//  virtual void Function03() const {
    void Function03() const {
            cout << "Interface Function03()" << endl;
    }

};
