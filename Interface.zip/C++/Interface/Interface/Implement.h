#pragma once
#include "InterfaceSpec.h"

class Implement : public InterfaceSpec
{
 public:
    Implement();
    ~Implement();

    void Function01() const;
    void Function01(const int n) const;
    void Function02() const;
    void Function03() const;

private:
    int x;
};
