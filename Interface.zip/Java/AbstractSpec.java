package Interface;

public abstract class AbstractSpec {
    // -- Define functions which must be implemented
	//    Use of the keyword abstract is mandatory in
	//    an abstract class definition. It is must be
	//    used to differentiate between concrete and
	//    abstract methods.
    public abstract void Function01();
    public abstract void Function01(int n);
    public abstract void Function02();
	public void Function03() {
		System.out.println("AbstractSpec Function03()");
	}
	
    // -- variables can be defined as static or non-static.
    //    interface cannot be instantiated and need not
	//    be final
    public int nonstaticvariable = 42;
    public static int staticvariable = 43;

}
