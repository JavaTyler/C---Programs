package Interface;

public class Main {

	public static void main(String[] args) {
		
		{
			System.out.println("static interface variables");
			System.out.println(InterfaceSpec.staticvariable);
			System.out.println(InterfaceSpec.nonstaticvariable);

			ImplementInterface imp = new ImplementInterface();
	
		    System.out.println("Direct calls though Implement class");
		    imp.Function01();
		    imp.Function01(10);
		    imp.Function02();
		    imp.Function03();
		    
		    InterfaceSpec iface;
		    // -- Principle of Substitution says that imp "is-a" Interface
		    //    (through inheritance) and therefore can be assigned
		    iface = imp;
		    
		    System.out.println("Substitution calls though InterfaceSpec class");
		    iface.Function01();
		    iface.Function01(10);
		    iface.Function02();
		    iface.Function03();
		}
		{
			System.out.println("static interface variables");
			System.out.println(AbstractSpec.staticvariable);
			
			// -- non-static so this operation will not compile
			// System.out.println(AbstractSpec.nonstaticvariable);

			ImplementAbstract imp = new ImplementAbstract();
	
		    System.out.println("Direct calls though Implement class");
		    imp.Function01();
		    imp.Function01(10);
		    imp.Function02();
		    imp.Function03();
		    imp.baseFunction03();
		    
		    // -- A variable of type abstract class must be a pointer type,
		    //    otherwise the compiler will try to create a call to the
		    //    default constructor.
		    AbstractSpec iface;
		    // -- Principle of Substitution says that imp "is-a" Interface
		    //    (through inheritance) and therefore can be assigned
		    iface = imp;
		    
		    System.out.println("Substitution calls though InterfaceSpec class");
		    iface.Function01();
		    iface.Function01(10);
		    iface.Function02();
		    iface.Function03();
		}
	}

}
