package Interface;

public class ImplementInterface implements InterfaceSpec {

	public ImplementInterface() {
	    System.out.println("Implement constructor");
	}
	
	@Override
	public void Function01() {
		System.out.println("Implement Function01()");
	}

	@Override
	public void Function01(int n) {
		System.out.println("Implement Function01(int n)");
	}

	@Override
	public void Function02() {
		System.out.println("Implement Function02()");
	}

	@Override
	public void Function03() {
		System.out.println("Implement Function03()");
	}

	@Override
	public boolean equals(Object i)
	{
		ImplementInterface ii = null;
		if (i instanceof ImplementInterface) {
//			ii = (ImplementInterface)i;
//			if (ii.???? == this.????) {
//				return true;
//			}
//			else {
//				return false;
//			}
		}
		return false;
	}
}







