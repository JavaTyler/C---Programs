package Interface;

public interface InterfaceSpec {
    // -- Define functions which must be implemented
	//    Use of the keyword abstract is optional in
	//    an interface definition. It is assumed to
	//    be there.
    public abstract void Function01();
    public abstract void Function01(int n);
    public abstract void Function02();
    public abstract void Function03();
    
    // -- variables can be defined only if they are declared
    //    as final. They may be specified as static or not
    //    but at runtime they are always static since the
    //    interface cannot be instantiated.
    public final int nonstaticvariable = 42;
    public static final int staticvariable = 43;

}
