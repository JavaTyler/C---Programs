package Interface;

public class ImplementAbstract extends AbstractSpec {

	public ImplementAbstract() {
	    System.out.println("Implement constructor");
	}
	
	@Override
	public void Function01() {
		System.out.println("Implement Function01()");
	}

	@Override
	public void Function01(int n) {
		System.out.println("Implement Function01(int n)");
	}

	@Override
	public void Function02() {
		System.out.println("Implement Function02()");
	}
	
	@Override
	public void Function03() {
		System.out.println("ImplementAbstract Function03()");
	}
	
	public void baseFunction03()
	{
		super.Function03();
	}

}
