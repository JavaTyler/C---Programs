//
//  main.cpp
//  Dynamic2DArray

// -- system header file
#include <iostream>
// -- project header file
#include "Dynamic2DArray.h"

using namespace std;

// -- The main() function is the application entry point.
//    It is global, it does not belong to any class and
//    there can only be one of them
int main(int argc, const char * argv[]) {
    
    // -- construct array using default constructor
    cout << "Default Constructor" << endl;
    Dynamic2DArray d2Da0;
    cout << d2Da0.toString() << endl;

    // -- construct array using overload constructor
    cout << "Overload Constructor" << endl;
    Dynamic2DArray d2Da1(2, 3);
    cout << d2Da1.toString() << endl;

    // -- construct array using copy constructor
    cout << "Copy Constructor" << endl;
    Dynamic2DArray d2Da2(d2Da1);
    cout << d2Da2.toString() << endl;

    // -- print the array using a pointer to access
    cout << "Pointer access" << endl;
    int* p = &(d2Da2.getArray()[0][0]);
    for (int i = 0; i < d2Da2.getR() * d2Da2.getC(); ++i, ++p) {
        cout << *p << endl;
    }
    cout << endl;

    // -- dynamic allocation
    cout << "Dynamic allocation" << endl;
    Dynamic2DArray* pd2Da = new Dynamic2DArray(4, 4);
    cout << pd2Da->toString() << endl;
    delete pd2Da;

    return 0;
}
