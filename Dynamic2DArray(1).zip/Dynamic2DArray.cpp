//
//  Dynamic2DArray.cpp
//  Dynamic2DArray

#include "Dynamic2DArray.h"

using namespace std;


Dynamic2DArray::Dynamic2DArray()
// -- initialize member varialbe before full construction
    :r(1)
    ,c(1)
{
    allocateArray();
}

// -- overload constructor
Dynamic2DArray::Dynamic2DArray(int r, int c)
    :r(r)
    , c(c)
{
    allocateArray();
}

// -- copy constructor
Dynamic2DArray::Dynamic2DArray(const Dynamic2DArray &src)
: r(src.r)
, c(src.c)
{
    allocateArray();
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            this->twoDarray[i][j] = src.twoDarray[i][j];
        }
    }
}

// -- helper function to allocate the array
void Dynamic2DArray::allocateArray()
{
    // -- allocate as non-contiguous memory
    //twoDarray = new int* [r];
    //for (int i = 0; i < r; ++i) {
    //    twoDarray[i] = new int[c];
    //}

    // -- allocate as contiguous memory
    twoDarray = new int* [r];
    twoDarray[0] = new int[r * c];

    for (int i = 1; i < r; ++i) {
        twoDarray[i] = twoDarray[i - 1] + c;
    }

    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            twoDarray[i][j] = i + j;
        }
    }
}

// -- destructor
Dynamic2DArray::~Dynamic2DArray()
{
    // -- delete when non-contiguous memory is used
    //for (int i = 0; i < r; ++i) {
    //    delete[] twoDarray[i];
    //}
    //delete[] twoDarray;

    // -- delete when contiguous memory is used
    delete[] twoDarray[0];
    delete[] twoDarray;
}

string Dynamic2DArray::toString()
{
    string s = "";
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            s += to_string(twoDarray[i][j]) + "\t";
        }
        s += "\n";
    }

   return s;
}
