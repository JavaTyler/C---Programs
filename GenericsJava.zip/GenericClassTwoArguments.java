package Generics;

public class GenericClassTwoArguments<TYPE1, TYPE2> {
	private TYPE1 data1;
	private TYPE2 data2;
	
	
	GenericClassTwoArguments(TYPE1 d1, TYPE2 d2) 
	 {
		 data1 = d1;
		 data2 = d2;
	 }

	 void setData1(TYPE1 d1)
	 {
		 data1 = d1;
	 }

	  TYPE1 getData1()
	  {
	    return data1;
	  }

		 void setData2(TYPE2 d2)
		 {
			 data2 = d2;
		 }

		  TYPE2 getData2()
		  {
		    return data2;
		  }

		  public String toString ()
	  {
			  return data1 + ", " + data2;
	  }

	  
	  public static void main (String args[])
	  {
		  GenericClassTwoArguments<Integer, Integer> iiGeneric = new GenericClassTwoArguments<Integer, Integer>(10, 11);
		  GenericClassTwoArguments<Integer, Double> idGeneric = new GenericClassTwoArguments<Integer, Double>(10, 11.10);
		  
			System.out.println(iiGeneric);
			System.out.println(idGeneric);
		  
	  }

}
