package Generics;


public class GenericMethod {

	// -- Use RTTI to ensure that the operations you are
	//    going to perform are valid for the dynamic (runtime)
	//    type
	public static <TYPE> TYPE genericMethod (TYPE d)
	{
		if (d instanceof Integer) {
			System.out.print("Integer ");
		}
		else if (d instanceof Double) {
			System.out.print("Double ");
		}
		else if (d instanceof String) {
			System.out.print("String ");
		}
		else if (d instanceof Object) {
			System.out.print("Object ");
		}
		else {
			System.out.print("Other ");
		}
		System.out.println(d);
		return d;
	}

	// -- can achieve the same results using Object since it is
	//    the root of all classes. The difference is that you won't
	//    get any compiler support (RTTI becomes critical)
	public static Object genericMethodO (Object d)
	{
		if (d instanceof Integer) {
			System.out.print("Integer ");
		}
		else if (d instanceof Double) {
			System.out.print("Double ");
		}
		else if (d instanceof String) {
			System.out.print("String ");
		}
		else if (d instanceof Object) {
			System.out.print("Object ");
		}
		else {
			System.out.print("Other ");
		}
		System.out.println(d);
		return d;
	}
	
	public static void main(String[] args) {
		System.out.println("Generic method");
		
		// -- auto-boxing will convert 42 to an
		//    object of type Integer
		Integer i = 42;
		Integer ii = genericMethod(i);
		
		// -- auto-boxing will convert 42.42 to an
		//    object of type Double
		Double d = 42.42;
		Double dd = genericMethod(d);

		String s = new String("hello, world");
		String ss = genericMethod(s);
		
		// -- auto-boxing will convert 42.42F to an
		//    object of type Float
		Float f = 42.42F;
		Float ff = genericMethod(f);

		// -- we don't actually need generics as the same end could
		//    be achieved using Object, the root of all ancestral trees.
		//    Use of generics allows the compiler to perform some type
		//    checking for us rather than risk run-time errors
		System.out.println("Object method");

		// -- auto-boxing will convert 42 to an
		//    object of type Integer
		Integer oi = 42;
		Integer oii = genericMethod(oi);
		
		// -- auto-boxing will convert 42.42 to an
		//    object of type Double
		Double od = 42.42;
		Double odd = genericMethod(od);

		String os = new String("hello, world");
		String oss = genericMethod(os);
		
		// -- auto-boxing will convert 42.42F to an
		//    object of type Float
		Float of = 42.42F;
		Float off = genericMethod(of);
	
	}

}
