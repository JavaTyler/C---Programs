package Generics;

// -- we don't actually need generics as the same end could
//    be achieved using Object, the root of all ancestral trees.
//    Use of generics allows the compiler to perform some type
//    checking for us rather than risk run-time errors

public class ObjectClass {
	private Object data;

	ObjectClass(Object d) {
		data = d;
	}

	void setData(Object d) {
		data = d;
	}

	Object getData() {
		return data;
	}

	void printData() {
		System.out.println(data);
	}

	public static void main(String args[]) {
		ObjectClass intobject = new ObjectClass(10);
		ObjectClass doubleobject = new ObjectClass(10.10);

		intobject.printData();
		doubleobject.printData();

	}

}
