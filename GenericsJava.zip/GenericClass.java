package Generics;
/* --
 Generics
    Enable you to detect errors at compile-time rather than runtime
    Can hold all (and only) class types no primitives
      auto-boxing and unboxing of the wrapper classes helps with this
    Restricts to a single class type (homogeneous)
    Will create a .class file for each compile-time instantiation
 -- */

public class GenericClass<TYPE> {
	private TYPE data;

	GenericClass(TYPE d) {
		data = d;
	}

	void setData(TYPE d) {
		data = d;
	}

	TYPE getData() {
		return data;
	}

	public String toString() {
		return data + "";
	}

	public static void main(String args[]) {
		GenericClass<Integer> intobject = new GenericClass<Integer>(10);
		GenericClass<Double> doubleobject = new GenericClass<Double>(10.10);

		System.out.println(intobject);
		System.out.println(doubleobject);

	}
}
